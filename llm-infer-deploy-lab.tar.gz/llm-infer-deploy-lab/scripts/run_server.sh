#!/bin/bash
# llama.cpp server 启动脚本
# 最优配置：ctx=4096, ngl=35, batch=256

LLAMA_CPP_DIR=$HOME/llama.cpp
MODEL_PATH=$HOME/models/qwen2.5-3b/qwen2.5-3b-instruct-q4_k_m.gguf
SERVER_PATH=$LLAMA_CPP_DIR/build/bin/llama-server

# 参数配置（基于 benchmark 最优结果）
CONTEXT_SIZE=4096
GPU_LAYERS=35
BATCH_SIZE=256

echo "启动 LLM 推理服务..."
echo "模型: $MODEL_PATH"
echo "配置: ctx=$CONTEXT_SIZE, ngl=$GPU_LAYERS, batch=$BATCH_SIZE"
echo "服务地址: http://localhost:8080"

$SERVER_PATH \
    -m $MODEL_PATH \
    -c $CONTEXT_SIZE \
    -ngl $GPU_LAYERS \
    -b $BATCH_SIZE \
    --host 0.0.0.0 \
    --port 8080 \
    --log-format text
