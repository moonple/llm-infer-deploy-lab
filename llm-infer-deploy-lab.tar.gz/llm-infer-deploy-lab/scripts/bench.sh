#!/bin/bash
# 基准测试脚本 - 自动记录显存

MODEL_PATH="$HOME/models/qwen2.5-3b/qwen2.5-3b-instruct-q4_k_m.gguf"
SERVER_PATH="$HOME/llama.cpp/build/bin/llama-server"
RESULTS_DIR="$HOME/llm-infer-deploy-lab/results"

# 确保结果目录存在
mkdir -p "$RESULTS_DIR"

# 测试参数组合
declare -a CONTEXTS=(2048 4096)
declare -a LAYERS=(20 35)
declare -a BATCHES=(256 512)

# 创建结果文件
TIMESTAMP=$(date +"%Y%m%d_%H%M%S")
RESULT_FILE="$RESULTS_DIR/bench_${TIMESTAMP}.md"

echo "# Benchmark Results - $(date)" > "$RESULT_FILE"
echo "## 测试环境" >> "$RESULT_FILE"
echo "- GPU: RTX 3060 6GB" >> "$RESULT_FILE"
echo "- 模型: Qwen2.5-3B-Instruct-Q4_K_M" >> "$RESULT_FILE"
echo "" >> "$RESULT_FILE"
echo "| ctx | ngl | batch | tokens/s | TTFT(ms) | 显存(MB) |" >> "$RESULT_FILE"
echo "|-----|-----|-------|----------|----------|----------|" >> "$RESULT_FILE"

# 清理函数
cleanup() {
    pkill -f llama-server 2>/dev/null
    sleep 2
}

# 获取当前显存使用
get_gpu_memory() {
    nvidia-smi --query-gpu=memory.used --format=csv,noheader,nounits | head -1
}

for ctx in "${CONTEXTS[@]}"; do
    for ngl in "${LAYERS[@]}"; do
        for batch in "${BATCHES[@]}"; do
            echo "==================================="
            echo "测试参数: ctx=$ctx, ngl=$ngl, batch=$batch"
            echo "==================================="
            
            cleanup
            
            # 记录基础显存
            BASE_MEM=$(get_gpu_memory)
            echo "基础显存: ${BASE_MEM}MB"
            
            # 启动server
            echo "启动服务器..."
            $SERVER_PATH \
                -m $MODEL_PATH \
                -c $ctx \
                -ngl $ngl \
                -b $batch \
                --host 127.0.0.1 \
                --port 8080 > server.log 2>&1 &
            
            SERVER_PID=$!
            
            # 等待模型加载，监控显存峰值
            echo "监控显存变化 (等待15秒)..."
            PEAK_MEM=$BASE_MEM
            for i in {1..15}; do
                sleep 1
                CURRENT_MEM=$(get_gpu_memory)
                if [ $CURRENT_MEM -gt $PEAK_MEM ]; then
                    PEAK_MEM=$CURRENT_MEM
                fi
                echo -n "."
            done
            echo ""
            echo "峰值显存: ${PEAK_MEM}MB"
            
            # 测试服务器健康状态
            echo "检查服务器健康状态..."
            HEALTH_CHECK=$(curl -s -o /dev/null -w "%{http_code}" http://localhost:8080/health)
            if [ "$HEALTH_CHECK" != "200" ]; then
                echo "健康检查失败 (HTTP $HEALTH_CHECK)"
                cleanup
                continue
            fi
            echo "健康检查通过"
            
            # 发送测试请求
            echo "发送测试请求..."
            curl -s http://localhost:8080/completion \
                -H "Content-Type: application/json" \
                -d '{
                    "prompt": "写一个50字的故事",
                    "n_predict": 50,
                    "temperature": 0.7
                }' > response.json
            
            # 从server日志中提取性能数据
            TOKEN_SPEED=$(grep "tokens/s" server.log | tail -1 | awk '{print $NF}')
            TTFT=$(grep "llama_print_timings:        ttft" server.log | tail -1 | awk '{print $4}' | sed 's/ms//')
            
            # 如果没找到，设置默认值
            if [ -z "$TOKEN_SPEED" ]; then
                TOKEN_SPEED="N/A"
            fi
            if [ -z "$TTFT" ]; then
                TTFT="N/A"
            fi
            
            # 计算实际模型显存占用（减去基础显存）
            MODEL_MEM=$((PEAK_MEM - BASE_MEM))
            
            # 写入结果
            echo "| $ctx | $ngl | $batch | $TOKEN_SPEED | $TTFT | ${MODEL_MEM} |" >> "$RESULT_FILE"
            
            echo "清理环境..."
            cleanup
            rm -f server.log response.json
            echo "完成本轮测试"
            echo ""
        done
    done
done

echo "==================================="
echo "测试完成！结果保存在: $RESULT_FILE"
echo "==================================="
cat "$RESULT_FILE"
