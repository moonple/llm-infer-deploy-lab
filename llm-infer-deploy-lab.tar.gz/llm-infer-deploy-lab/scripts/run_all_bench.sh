#!/bin/bash
# 完整 benchmark 脚本

MODEL_PATH="$HOME/models/qwen2.5-3b/qwen2.5-3b-instruct-q4_k_m.gguf"
SERVER_PATH="$HOME/llama.cpp/build/bin/llama-server"
RESULT_FILE="$HOME/llm-infer-deploy-lab/results/bench_final.md"

# 测试参数组合 (ctx, ngl, batch)
CONFIGS=(
    "2048 20 256"
    "2048 20 512"
    "2048 35 256"
    "2048 35 512"
    "4096 20 256"
    "4096 20 512"
    "4096 35 256"
    "4096 35 512"
)

echo "# Benchmark Results - $(date)" > "$RESULT_FILE"
echo "" >> "$RESULT_FILE"
echo "## 测试环境" >> "$RESULT_FILE"
echo "- GPU: RTX 3060 6GB" >> "$RESULT_FILE"
echo "- 模型: Qwen2.5-3B-Instruct-Q4_K_M" >> "$RESULT_FILE"
echo "- llama.cpp 版本: $(cd ~/llama.cpp && git rev-parse --short HEAD)" >> "$RESULT_FILE"
echo "" >> "$RESULT_FILE"
echo "| 序号 | ctx | ngl | batch | tokens/s | TTFT(ms) | 模型显存(MB) | 总显存(MB) |" >> "$RESULT_FILE"
echo "|------|-----|-----|-------|----------|----------|--------------|------------|" >> "$RESULT_FILE"

idx=1
for config in "${CONFIGS[@]}"; do
    read ctx ngl batch <<< "$config"
    
    echo ""
    echo "========================================="
    echo "[$idx/8] 测试: ctx=$ctx, ngl=$ngl, batch=$batch"
    echo "========================================="
    
    # 清理旧进程
    pkill -f llama-server 2>/dev/null
    sleep 2
    
    # 记录基础显存
    BASE_MEM=$(nvidia-smi --query-gpu=memory.used --format=csv,noheader,nounits)
    echo "基础显存: ${BASE_MEM} MB"
    
    # 启动 server 并记录日志
    $SERVER_PATH \
        -m $MODEL_PATH \
        -c $ctx \
        -ngl $ngl \
        -b $batch \
        --host 127.0.0.1 \
        --port 8080 2>&1 | tee /tmp/bench_${ctx}_${ngl}_${batch}.log &
    
    SERVER_PID=$!
    
    # 等待模型加载
    echo -n "等待模型加载"
    for i in {1..20}; do
        sleep 1
        echo -n "."
    done
    echo ""
    
    # 获取模型显存（从日志中提取）
    MODEL_MEM=$(grep "CUDA0 model buffer size" /tmp/bench_${ctx}_${ngl}_${batch}.log | grep -oP '\d+\.\d+' | head -1)
    if [ -z "$MODEL_MEM" ]; then
        MODEL_MEM="N/A"
    fi
    
    # 获取总显存峰值
    PEAK_MEM=$(nvidia-smi --query-gpu=memory.used --format=csv,noheader,nounits)
    echo "当前显存: ${PEAK_MEM} MB"
    echo "模型显存: ${MODEL_MEM} MB"
    
    # 发送测试请求
    echo "发送测试请求..."
    curl -s -X POST http://localhost:8080/completion \
        -H "Content-Type: application/json" \
        -d '{
            "prompt": "解释什么是人工智能，用50字左右",
            "n_predict": 50,
            "temperature": 0.7
        }' > /tmp/response.json
    
    # 等待请求完成
    sleep 2
    
    # 从日志中提取性能数据
    TOKEN_SPEED=$(grep "eval time" /tmp/bench_${ctx}_${ngl}_${batch}.log | tail -1 | grep -oP '\d+\.\d+ tokens per second' | grep -oP '\d+\.\d+')
    TTFT=$(grep "prompt eval time" /tmp/bench_${ctx}_${ngl}_${batch}.log | tail -1 | grep -oP '\d+\.\d+ ms' | grep -oP '\d+\.\d+' | head -1)
    
    if [ -z "$TOKEN_SPEED" ]; then
        TOKEN_SPEED="N/A"
    fi
    if [ -z "$TTFT" ]; then
        TTFT="N/A"
    fi
    
    echo "结果: tokens/s=$TOKEN_SPEED, TTFT=${TTFT}ms"
    
    # 写入结果
    echo "| $idx | $ctx | $ngl | $batch | $TOKEN_SPEED | $TTFT | $MODEL_MEM | $PEAK_MEM |" >> "$RESULT_FILE"
    
    # 停止服务器
    kill $SERVER_PID 2>/dev/null
    sleep 2
    
    idx=$((idx+1))
done

echo ""
echo "========================================="
echo "测试完成！结果保存在: $RESULT_FILE"
echo "========================================="
cat "$RESULT_FILE"
